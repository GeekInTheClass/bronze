//: Playground - noun: a place where people can play

import UIKit

//401번 돌기전에 끝나는 최대공약수 찾기
var a = 16, b = 10, tmr = 0
for i in 0 ... 400 where b != 0 {
    tmr = a%b
    a = b
    b = tmr
}
print("\(a)")

//3개의 인접한 숫자 중의 최대값 찾기

var array:[Int] = [1,3,2,5,6,1,3,5]
var k=3 , maxs = 0
for i in 0...array.count where i < array.count-k+1 {
    var tot = 0
    for p in i..<i+k
    {
        tot=tot+array[p]
    }
    maxs=max(maxs,tot)
}
print("\(maxs)")

//최대값 찾기

var arrs:[Int] = [1,2,3,5,6,7,3,55]
var ar:Int = arrs[0]
for i in arrs {
    ar=max(ar,i)
}
print("\(ar)")